gcausal <-
function(datamatrix,
				type="conditional",
				lagmethod="first",
				maxnumlags=1,
				maxlag=1,
				crit="aicc", 
				ty.test=FALSE,
				int.maxorder=2,
				stat.method="KPSS",
				stat.cutoff=0.05,
				sibling.filter=FALSE,
				sf.mincor=0.7,
				sf.maxlag=2,			
				rank.method="dynamic",
				search.speed=3,
				sf.matrix,
				rank.matrix){
	if (any(!all(is.numeric(datamatrix)))){stop("Non numeric values found")}	
	if (any(is.na(datamatrix))){stop("NA values found")}
	if (any(abs(datamatrix)==Inf)){stop("Inf values found")}
	exprdata=t(datamatrix)
	## sibling matrix			
	if (missing(sf.matrix)){
		sf.matrix=mat.or.vec(nrow(exprdata),nrow(exprdata))
		if (sibling.filter==TRUE){
			print("inferring siblings")
			sf.matrix=gci.sibling.fun(exprdata,sf.mincor,sf.maxlag)}}			
	## order of integration 	
	oiall=NULL
	if (ty.test==TRUE){
		oiall=apply(exprdata,1,function(x) gci.order.int(x,int.maxorder=int.maxorder, cutoff=stat.cutoff, method=stat.method))}	
	if (type=="bivariate"){	
		print("Pairwise Granger causality test")
		out=gci.gcausal2(exprdata,lagmethod,maxnumlags,maxlag,crit,ty.test,oiall,sf.matrix)}
	if (type=="conditional"){
		if (missing(rank.matrix)){
			if (rank.method=="dynamic"){
				print("computing ranking matrix")
				## use simple dynamic parameters
				rank.matrix=gci.gcausal2(exprdata,"first",1,1,crit,ty.test=FALSE)}		
			if (rank.method=="static"){
				rank.matrix=mi(exprdata)}}
		print("")
		print("1 order conditional Granger causality test")
		out=gci.gcausal3(exprdata,lagmethod,maxnumlags,maxlag,crit,ty.test,oiall,sf.matrix,rank.method,rank.matrix,search.speed)}
	colnames(out)=rownames(exprdata)
	rownames(out)=rownames(exprdata)
	return(out)}
