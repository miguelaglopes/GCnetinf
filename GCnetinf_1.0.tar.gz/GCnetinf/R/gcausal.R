gcausal <-
function(datamatrix,
				type="conditional",
				lagmethod="first",
				maxnumlags=1,
				maxlag=1,
				crit="aicc", 
				ty.test=FALSE,
				stat.pars,
				sibling.filter=FALSE,
				sf.mincor=0.7,
				sf.maxlag=2	,		
				sf.matrix,
				gc3rank.method="dynamic",
				gc3rank.approx=3,
				gc3rank.matrix){
	if (any(!all(is.numeric(datamatrix)))){stop("Non numeric values found")}	
	if (any(is.na(datamatrix))){stop("NA values found")}
	if (any(abs(datamatrix)==Inf)){stop("Inf values found")}
	exprdata=t(datamatrix)
	
	## non stationarity tests
	if (missing(stat.pars)){
		stat.pars=list(maxorder=2, method="KPSS", cutoff=0.05)}
	int.maxorder=stat.pars$maxorder
	stat.method=stat.pars$method
	stat.cutoff=stat.pars$cutoff	
	
	## sibling matrix			
	if (missing(sf.matrix)){
		sf.matrix=mat.or.vec(nrow(exprdata),nrow(exprdata))
		if (sibling.filter==TRUE){
			print("Inferring siblings")
			sf.matrix=gci.sibling.fun(exprdata,sf.mincor,sf.maxlag)}}			
	## order of integration 	
	oiall=NULL
	if (ty.test==TRUE){
		oiall=apply(exprdata,1,function(x) gci.order.int(x,int.maxorder=int.maxorder, cutoff=stat.cutoff, method=stat.method))}	
	if (type=="bivariate"){	
		print("Pairwise Granger causality test")
		out=gci.gcausal2(exprdata,lagmethod,maxnumlags,maxlag,crit,ty.test,oiall,sf.matrix)}
	if (type=="conditional"){
		if (missing(gc3rank.matrix)){
			if (gc3rank.method=="dynamic"){
				print("Computing ranking matrix")
				## use simple dynamic parameters
				gc3rank.matrix=gci.gcausal2(exprdata,"first",1,1,crit,ty.test=FALSE)}		
			if (gc3rank.method=="static"){
				print("Computing ranking matrix")
				gc3rank.matrix=gci.mi(exprdata)}}
		print("1 order conditional Granger causality test")
		out=gci.gcausal3(exprdata,lagmethod,maxnumlags,maxlag,crit,ty.test,oiall,sf.matrix,gc3rank.method,gc3rank.matrix,gc3rank.approx)}
	colnames(out)=rownames(exprdata)
	rownames(out)=rownames(exprdata)
	return(out)}
