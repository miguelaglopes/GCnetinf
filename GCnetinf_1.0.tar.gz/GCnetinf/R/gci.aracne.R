gci.aracne <-
function(mi.mat){
	print("ARACNE")
	mi.matS=mi.mat
	mi.matS[which(mi.mat<t(mi.mat))]=t(mi.mat)[which(mi.mat<t(mi.mat))]
	diag(mi.matS)=0
	pred.rem=mi.mat*0
	checkseq=1:100
	for (i in 1:(nrow(mi.mat)-2)){
		if (any(checkseq==round(i/nrow(mi.mat),2)*100)){
			checkseq=checkseq[-which(checkseq==round(i/nrow(mi.mat),2)*100)]
			cat(paste(round(i/nrow(mi.mat),2)*100, "% ", sep=""))}
		for (j in (i+1):(nrow(mi.mat)-1)){
			for (k in 1:nrow(mi.mat)){
				m=min(mi.matS[i,k],mi.matS[j,k])
				if (mi.matS[i,j]<m){
					pred.rem[i,j]=1}}}}
	pred.rem=pred.rem+t(pred.rem)
	ind.rem=which(pred.rem!=0)
	mi.mat[ind.rem]=min(mi.mat)-0.1
	return(mi.mat)}
