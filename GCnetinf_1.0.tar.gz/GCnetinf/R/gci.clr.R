gci.clr <-
function(mi.mat){
	print("CLR")
	out=mi.mat*0
	checkseq=1:100
	for (i in 1:nrow(mi.mat)){
		if (any(checkseq==round(i/nrow(mi.mat),2)*100)){
			checkseq=checkseq[-which(checkseq==round(i/nrow(mi.mat),2)*100)]
			cat(paste(round(i/nrow(mi.mat),2)*100, "% ", sep=""))}
		for (j in 1:nrow(mi.mat)){	
			fact1=(mi.mat[i,j]-mean(mi.mat[i,-i]))/sd(mi.mat[i,-i])
			fact2=(mi.mat[i,j]-mean(mi.mat[-j,j]))/sd(mi.mat[-j,j])
			fact1=max(0,fact1)
			fact2=max(0,fact2)
			out[i,j]=sqrt(fact1^2+fact2^2)
			}}
	return(out)}
