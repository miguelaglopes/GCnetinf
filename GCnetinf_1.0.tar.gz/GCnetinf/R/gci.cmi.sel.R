gci.cmi.sel <-
function(preds,target,mi.mat,type){
	allpreds=1:nrow(preds)
	out=numeric(nrow(preds))	
	selected=which.max(mi.mat[-ncol(mi.mat), ncol(mi.mat)])
	out[selected]=mi.mat[selected, ncol(mi.mat)]
	if(length(allpreds)>1){
	for (s in 2:length(allpreds)){
		maxscore=-100000000
		for (s1 in setdiff(allpreds,selected)){
			mi=mi.mat[s1, ncol(mi.mat)]					
			scorestemp=NULL
			for (selected2 in selected){
				temp=gci.cor2mi(ppcor::pcor( cbind(preds[s1,], preds[selected2,], target))[[1]][1,3])
				scorestemp=c(scorestemp,temp)}
			if (type=="mean"){
				score=mean(scorestemp)
				if (score>maxscore){
					maxscore=score
					candidate=s1}}
			if (type=="min"){
				score=min(scorestemp)
				if (score>maxscore){
					maxscore=score
					candidate=s1}}}
		out[candidate]=maxscore
		selected=c(selected, candidate)}}		
	return(out)}
