gci.cmim <-
function(exprdata,cutoff){
	print("CMIM")
	out=gci.vsel1pcor(exprdata, method="cmim",cutoff)
	return(out)}
