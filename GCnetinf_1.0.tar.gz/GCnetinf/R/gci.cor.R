gci.cor <-
function(x,y){
	x=x[-length(x)]
	y=y[-1]
	return(cor(x,y))}
