gci.cor.mat <-
function(exprdata){
	print("lagged correlations")
	cor.mat=mat.or.vec(nrow(exprdata), nrow(exprdata))
	checkseq=1:100
	for (i in 1:nrow(exprdata)){
		if (any(checkseq==round(i/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(i/nrow(exprdata),2)*100)]
			cat(paste(round(i/nrow(exprdata),2)*100, "% ", sep=""))}
		for (j in 1:nrow(exprdata)){
			cor.mat[i,j]=gci.cor(exprdata[i,], exprdata[j,])
			}}
	return(cor.mat)}
