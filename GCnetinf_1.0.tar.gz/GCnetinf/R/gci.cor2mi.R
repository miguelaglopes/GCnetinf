gci.cor2mi <-
function(rho){
	rho=abs(rho)
	rho<-pmin(rho,1-1e-5)
		-1/2*log(1-rho^2)}
