gci.corrPV <-
function(corr.value, N){
	corr.value=abs(corr.value)
	z.value=0.5*log((1+corr.value)/(1-corr.value))
	sd.value=1/sqrt(N-3)
	pvalue=pnorm(z.value,0,sd.value,lower.tail=FALSE)
	return(pvalue)}
