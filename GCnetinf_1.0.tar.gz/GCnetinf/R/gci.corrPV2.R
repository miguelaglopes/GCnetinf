gci.corrPV2 <-
function(corr.value, N){
	corr.value=abs(corr.value)
	tval=corr.value*sqrt( (N-2)/(1-corr.value^2))
	## follows t with degrees of freedom n-2
	pvalue=pt(tval, df=N-2, lower.tail = FALSE)
	return(pvalue)}
