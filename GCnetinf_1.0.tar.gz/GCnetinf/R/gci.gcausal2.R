gci.gcausal2 <-
function(exprdata,
				lagmethod,
				maxnumlags,
				maxlag,
				crit, 
				ty.test,
				oiall,
				sf.matrix){										
	ngenes=nrow(exprdata)
	npoints=ncol(exprdata)
	out=mat.or.vec(ngenes,ngenes)+NA
	if (missing(sf.matrix)){
		sf.matrix=mat.or.vec(ngenes, ngenes)}	
	if (maxlag<maxnumlags){
		maxnumlags=maxlag}						
	exprdata=t(apply(exprdata,1,function(x) (x-mean(x))/sd(x)))	
	printseq=paste( round((1:ngenes)/ngenes,1)*100,"% ",sep="")
	checkseq=which(diff(round((1:ngenes)/ngenes,1))!=0)+1	
	for (i in 1:ngenes){		
		if (any(checkseq==i)){
			cat(printseq[i])}
		geneB=exprdata[i,]
		lags.outB=gci.lag.selection.first(geneB,geneB,maxnumlags,crit) 			 		
		lagsB=lags.outB[[2]]
		predsB=lags.outB[[3]]
		for (j in which(sf.matrix[i,]==0)){
			geneA=exprdata[j,]
			if (lagmethod=="first"){
				lags.outA=gci.lag.selection.firstfix(geneB,geneA,lagsB,predsB)}
			if (lagmethod=="fsel"){			
				lags.outA=gci.lag.selection.fsel(geneB, geneA, maxnumlags=length(lagsB), maxlag, predsB, fixed=TRUE,crit)}			
			lagsA=lags.outA[[2]]
			preds=NULL
			REM=max(c(lagsA, lagsB))
			if (ty.test==TRUE){
				oi=max(oiall[i,j])
				if (oi>0){
					lagsA.ty.test=setdiff( (1:length(geneA)), lagsA)[1:oi] 
					lagsB.ty.test=setdiff( (1:length(geneB)), lagsB)[1:oi] 
					REM=max(c(REM,lagsA.ty.test,lagsB.ty.test))
					preds.ty.test=NULL
					for (s in lagsA.ty.test){	
			 			preds.ty.test=cbind(preds.ty.test, c( rep(NA,s), geneA[1:(npoints-s)]))}
					for (s in lagsB.ty.test){	
			 			preds.ty.test=cbind(preds.ty.test, c( rep(NA,s), geneB[1:(npoints-s)]))}
			 		preds=preds.ty.test}}
			for (s in lagsB){	
		 		preds=cbind(preds, c( rep(NA,s), geneB[1:(npoints-s)]))}	
			predsNEW=preds[-(1:REM),]
			geneBNEW=geneB[-(1:REM)]
			## restricted model ##
			lm.out=lm(geneBNEW~predsNEW)
			residR=lm.out[[2]]		
			for (s in lagsA){		
		 		preds=cbind(preds, c( rep(NA,s), geneA[1:(npoints-s)]))}	
			predsNEW=preds[-(1:REM),]
			geneBNEW=geneB[-(1:REM)]
			## unrestricted model ##
			lm.out=lm(geneBNEW~predsNEW)
			residU=lm.out[[2]]			
			rss1=sum(residR^2)
			rss2=sum(residU^2)
			N=length(residR)			
			df1=length(lagsA) 
			df2=(N-(2*df1)-1)
			score_gs=(rss1-rss2)/(rss2) 
			score_gs=score_gs*df2/df1
			score_gs=pf(score_gs, df1, df2, lower.tail = FALSE)
			score_gs=qnorm(score_gs, lower.tail=FALSE)	
			out[j,i]=score_gs}}
	diag(out)=0	
	cat("\n")
	return(out)}
