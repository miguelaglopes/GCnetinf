gci.gcausal3 <-
function(exprdata,
				lagmethod,
				maxnumlags,
				maxlag,
				crit, 
				ty.test,
				oiall,
				sf.matrix,			
				gc3rank.method,
				gc3rank.matrix,
				gc3rank.approx){	
	ngenes=nrow(exprdata)
	npoints=ncol(exprdata)
	out=mat.or.vec(ngenes,ngenes)+NA
	if (maxlag<maxnumlags){
		maxnumlags=maxlag}				
	exprdata=t(apply(exprdata,1,function(x) (x-mean(x))/sd(x)))
	minseq=gc3rank.approx
	prediction=mat.or.vec(ngenes,ngenes)
	printseq=paste( round((1:ngenes)/ngenes,1)*100,"% ",sep="")
	checkseq=which(diff(round((1:ngenes)/ngenes,1))!=0)+1	
	for (i in 1:ngenes){		
		if (any(checkseq==i)){
			cat(printseq[i])}
		geneB=exprdata[i,]
		lags.outB=gci.lag.selection.first(geneB,geneB,maxnumlags,crit) 			 		
		resid1=lags.outB[[1]]
		lagsB=lags.outB[[2]]
		predsB=lags.outB[[3]]
		for (j in which(sf.matrix[i,]==0)){
			geneA=exprdata[j,]
			if (lagmethod=="first"){
				lags.outA=gci.lag.selection.firstfix(geneB,geneA,lagsB,predsB)}
			if (lagmethod=="fsel"){			
				lags.outA=gci.lag.selection.fsel(geneB, geneA, maxnumlags=length(lagsB), maxlag, predsB, fixed=TRUE,crit)}			
			resid2=lags.outA[[1]]
			lagsA=lags.outA[[2]]
			predsA=lags.outA[[3]]			
			### ranking of variables for conditional GC extension 
			if (gc3rank.method=="dynamic"){
			 	gc.k1=gc3rank.matrix[,i] ## to the target 
			 	gc.k2=apply(cbind( gc3rank.matrix[j,] , gc3rank.matrix[,j] ), 1, max) ## max( GC(k->x), GC(x->k))
			 	score=gc.k1+gc.k2}
			if (gc3rank.method=="static"){
			 	score=gc3rank.matrix[,i]+gc3rank.matrix[,j]}	  	
		  	score[c(i,j)]=min(score)
		 	K.ranked=sort(score, index.return=TRUE, decreasing=TRUE)[[2]]	
		 	K.ranked=setdiff(K.ranked, which(sf.matrix[j,]!=0))
		 	rss.score.min=10000 ##
		 	nseq=0
		 	for (k in K.ranked){
				geneK=exprdata[k,]
				geneK=(geneK-mean(geneK))/sd(geneK)		 		
				preds=NULL
				REM=max(c(lagsA, lagsB))
				if (ty.test==TRUE){
					oi=max(oiall[c(i,j,k)])
					if (oi>0){
						lagsA.ty.test=setdiff( (1:length(geneA)), lagsA)[1:oi] 
						lagsB.ty.test=setdiff( (1:length(geneB)), lagsB)[1:oi] 
						REM=max(c(REM,lagsA.ty.test,lagsB.ty.test))
						preds.ty.test=NULL
						for (s in lagsA.ty.test){	
			 				preds.ty.test=cbind(preds.ty.test, c( rep(NA,s), geneA[1:(npoints-s)]))}
						for (s in lagsB.ty.test){	
			 				preds.ty.test=cbind(preds.ty.test, c( rep(NA,s), geneB[1:(npoints-s)]))
			 				preds.ty.test=cbind(preds.ty.test, c( rep(NA,s), geneK[1:(npoints-s)]))}
			 			preds=preds.ty.test}}			
				for (s in lagsB){	
		 			preds=cbind(preds, c( rep(NA,s), geneB[1:(npoints-s)]))	
					preds=cbind(preds, c( rep(NA,s), geneK[1:(npoints-s)]))	
					}
				predsNEW=preds[-(1:REM),]
				geneBNEW=geneB[-(1:REM)]
				## restricted model ##
				lm.out=lm(geneBNEW~predsNEW)
				residR=lm.out[[2]]		
				for (s in lagsA){		
		 			preds=cbind(preds, c( rep(NA,s), geneA[1:(npoints-s)]))}	
				predsNEW=preds[-(1:REM),]
				## unrestricted model ##
				lm.out=lm(geneBNEW~predsNEW)
				residU=lm.out[[2]]			
				rss1=sum(residR^2)
				rss2=sum(residU^2)	 		
			 	rss.score=(rss1-rss2)/rss2
				if (rss.score>=rss.score.min){
					nseq=nseq+1}
				if (nseq>=minseq){
					break}		
				if (rss.score<rss.score.min){
					rss.score.min=rss.score
					nseq=0}}
		 	if (rss.score.min<10000){
		 		score_gs=rss.score.min					
				N=length(lm.out[[2]])			
				df1=length(lagsA) 
				df2=(N-(3*df1)-1)
				score_gs=score_gs*df2/df1
				score_gs=pf(score_gs, df1, df2, lower.tail = FALSE)
				score_gs=qnorm(score_gs, lower.tail=FALSE)	
				out[j,i]=score_gs}}}
	diag(out)=0	
	cat("\n")
	return(out)}
