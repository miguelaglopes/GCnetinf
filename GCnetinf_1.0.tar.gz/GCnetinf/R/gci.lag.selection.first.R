gci.lag.selection.first <-
function(geneB,geneA,maxnumlags,crit){	 			 		
		if (missing(crit)){
			crit="aicc"}
		npoints=length(geneA) 	
		rss_all=list()
		selected_all=list()
		models_all=list()			
		preds=NULL
		for (s in 1:maxnumlags){			 	
		 	preds=cbind(preds, c( rep(NA,s), geneA[1:(npoints-s)]))	
			predsNEW=preds[-(1:s),]
			geneBNEW=geneB[-(1:s)]
			models_all[[s]]=lm(geneBNEW~predsNEW)
		 	selected_all[[s]]=1:s}
		best.crit=1000000000
		crit_all=numeric(length(rss_all))
		for (n in 1:maxnumlags){
			crit_all[n]=gci.regr.crit(models_all[[n]], crit)}				
		nsel=which.min(crit_all)
		lags=selected_all[[nsel]] 	
		predsA=preds[,lags] 
		output=list()
		output[[1]]=models_all[[nsel]][[2]]	## residuals 
		output[[2]]=lags ## lags 
		output[[3]]=predsA
		names(output)=c("residuals","lags","preds")
		return(output)}
