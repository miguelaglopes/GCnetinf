gci.lag.selection.firstfix <-
function(geneB,geneA,lags,preds){	 			 		
	if (missing(preds)){
		preds=NULL}			
	npoints=length(geneA) 	
	rss_all=list()
	selected_all=list()
	models_all=list()			
	predsA=NULL
	for (s in lags){			 	
	 	predsA=cbind(predsA, c( rep(NA,s), geneA[1:(npoints-s)]))}
	preds=cbind(preds,predsA)
	predsNEW=preds[-(1:max(lags)),]
	geneBNEW=geneB[-(1:max(lags))]
	models_all=lm(geneBNEW~predsNEW)
	output=list()
	output[[1]]=models_all[[2]]	## residuals 
	output[[2]]=lags ## lags 
	output[[3]]=predsA
	names(output)=c("residuals","lags","preds")
	return(output)}
