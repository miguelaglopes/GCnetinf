gci.lag.selection.fsel <-
function(geneB, geneA, maxnumlags, maxlag, preds, fixed,crit){
		if (missing(maxlag)){
			maxlag=maxnumlags}
		if (missing(crit)){
			crit="aicc"}
		if (missing(preds)){
			preds=NULL}	
		if (missing(fixed)){
			fixed=FALSE}		
		if (maxnumlags>maxlag){
			maxnumlags=maxlag}							
		npoints=length(geneA)
		predsA=NULL
		for (s in 1:maxlag){			
		 	predsA=cbind(predsA, c( rep(NA,s), geneA[1:(npoints-s)]))}		 	
		rss_all=list()
		selected=NULL			
		models_all=list()			
		remaining=1:maxlag
		criterion.last=100000000
		crit_all=NULL	
		predictors=preds
		currentmaxlag=0
		for (n in 1:maxnumlags){
			score.min=1000000
		 	for (l in remaining){
				predictors_test=cbind(predictors, predsA[,l])
				currentmaxlag2=currentmaxlag
				if (l>currentmaxlag){
					currentmaxlag2=l}
				predsNEW=predictors_test[-(1:currentmaxlag2),]
				geneBNEW=geneB[-(1:currentmaxlag2)]			
				lm.out2=lm(geneBNEW~predsNEW)				
		 		rss2=sum( lm.out2[[2]]^2 )
		 		score=gci.regr.crit(lm.out2, crit)
		 		if (score<score.min){
		 			s=l
		 			score.min=score
		 			rss.min=rss2
		 			lm.model=lm.out2
		 			}}
			crit_all[n]=score.min
		 	models_all[[n]]=lm.model
		 	selected=c(selected, s)
		 	predictors=cbind(predictors, predsA[,s])	
		 	remaining=remaining[-which(remaining==s)]
		 	if (s>currentmaxlag){
				currentmaxlag=s}}
		 if (fixed==TRUE){
		 	lags=selected[1:maxnumlags]
		 	resid2=models_all[[maxnumlags]][[2]]}
		 if (fixed==FALSE){
		 	nsel=which.min(crit_all)
			lags=selected[1:nsel]
			resid2=models_all[[nsel]][[2]]}					 		 	
		output=list()
		output[[1]]=resid2
		output[[2]]=lags
		output[[3]]=predsA[,lags]		
		names(output)=c("residuals","lags","preds")
		return(output)}
