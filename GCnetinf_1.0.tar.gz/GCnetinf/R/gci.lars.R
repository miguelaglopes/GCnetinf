gci.lars <-
function(exprdata, lars.pars, predict.lars.pars){
	print("LASSO")
	prediction=mat.or.vec(nrow(exprdata),nrow(exprdata))
	checkseq=1:100
	for (y in 1:nrow(exprdata)){
		if (any(checkseq==round(y/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(y/nrow(exprdata),2)*100)]
			cat(paste(round(y/nrow(exprdata),2)*100, "% ", sep=""))}
		target=exprdata[y,-1]
		target=(target-mean(target))/sd(target)
		predictors=exprdata[,-ncol(exprdata)]
		predictors=t(apply(predictors, 1, function(x) (x-mean(x))/sd(x)))
		rownames(predictors)=1:nrow(predictors)	
		prediction[,y]=gci.lars.target(target, predictors, lars.pars, predict.lars.pars)
		}
	return(prediction)}
