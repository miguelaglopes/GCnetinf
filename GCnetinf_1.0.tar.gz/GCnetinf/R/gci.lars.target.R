gci.lars.target <-
function(target, predictors, lars.pars, predict.lars.pars){
	if (is.null(dim(predictors))){
		predictors=as.matrix(t(predictors))}
	lars.pars=c(list(x=t(predictors), y=target), lars.pars)
	a=do.call(lars::lars, lars.pars)	
	predict.lars.pars=c(list(object=a), predict.lars.pars)
	b=do.call(lars::predict.lars, predict.lars.pars)
	pred=b$coefficients
	if (is.null(dim(pred))){
		out=mean(pred)}
	if (!is.null(dim(pred))){
		out=abs(apply(pred,2,mean))} 
		## mean of the coefficients along the path
	return(out)}
