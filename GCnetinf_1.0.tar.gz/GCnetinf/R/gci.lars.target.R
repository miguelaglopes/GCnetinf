gci.lars.target <-
function(target, predictors, lars.type, lars.use.gram, lars.mode, lars.path){
	if (is.null(dim(predictors))){
		predictors=as.matrix(t(predictors))}
	a=lars::lars( t(predictors), target, type=lars.type, use.Gram=lars.use.gram)
	## sample the path along 0 to 1, separated by 0.1 of magnitude solution/magnitude OLS
	b=lars::predict.lars(a,type="coefficients", mode=lars.mode, s=lars.path)	
	pred=b[[4]]
	if (is.null(dim(pred))){
		out=mean(pred)}
	if (!is.null(dim(pred))){
		out=abs(apply(pred,2,mean))} 
		## mean of the coefficients along the path
	return(out)}
