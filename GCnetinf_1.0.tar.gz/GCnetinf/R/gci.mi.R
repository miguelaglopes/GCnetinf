gci.mi <-
function(exprdata){
	cor.mat=cor(t(exprdata))
	mi.mat=gci.cor2mi(cor.mat)
	return(mi.mat)}
