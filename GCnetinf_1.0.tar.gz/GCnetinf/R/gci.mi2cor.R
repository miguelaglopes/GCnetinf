gci.mi2cor <-
function(mi){
	rho=sqrt(1-exp(-2*mi))
	return(rho)}
