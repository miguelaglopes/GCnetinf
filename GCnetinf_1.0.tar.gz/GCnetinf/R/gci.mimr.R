gci.mimr <-
function(exprdata,cutoff){
	print("MIMR")
	out=gci.vsel1pcor(exprdata, method="mimr",cutoff)
	return(out)}
