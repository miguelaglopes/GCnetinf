gci.mrmr <-
function(exprdata){
	print("MRMR")
	n.genes=nrow(exprdata)
	out=mat.or.vec(n.genes, n.genes)
	checkseq=1:100
	for (i in 1:n.genes){
		if (any(checkseq==round(i/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(i/nrow(exprdata),2)*100)]
			cat(paste(round(i/nrow(exprdata),2)*100, "% ", sep=""))}
		target=exprdata[i,-1]
		preds=exprdata[,-ncol(exprdata)]
		cor.mat=rbind(preds,target)
		cor.mat=cor(t(cor.mat))
		mi.mat=gci.cor2mi(cor.mat)
		out[,i]=gci.mrmr.sel(mi.mat)}
	return(out)}
