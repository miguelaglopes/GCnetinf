gci.mrmr.sel <-
function(mi.mat){
	allpreds=1:(nrow(mi.mat)-1)
	out=numeric(nrow(mi.mat)-1)	
	selected=NULL
	for (s in 1:length(allpreds)){
		maxscore=-100000000
		for (s1 in setdiff(allpreds,selected)){
			mi=mi.mat[s1, ncol(mi.mat)]		
			# redundancy with prev selected 
			if (length(selected)>0){
				red=mean(mi.mat[s1, selected])
				score=mi-red}
			if (length(selected)==0){
				score=mi}
			if (score>maxscore){
				maxscore=score
				candidate=s1}}
		selected=c(selected,candidate)
		out[candidate]=maxscore}
	return(out)}
