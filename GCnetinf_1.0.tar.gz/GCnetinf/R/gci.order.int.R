gci.order.int <-
function(x, int.maxorder, cutoff, method){
	if (missing(method)){
		method="KPSS"}
	tests=list()
	if (method=="adf"){
		tests[[1]]=tseries::adf.test(x, alternative="explosive")[[4]]}
	if (method=="KPSS"){
		tests[[1]]=tseries::kpss.test(x)[[3]]}
	if (int.maxorder>1){
		for (i in 2:int.maxorder){
			x=diff(x)
			if (method=="adf"){
				tests[[i]]=tseries::adf.test(x, alternative="explosive")[[4]]}
			if (method=="KPSS"){
				tests[[i]]=tseries::kpss.test(x)[[3]]}
			}}
	tests=unlist(tests)		
	int.ord=which(tests>=cutoff)
	if (length(int.ord)==0){
		ord=int.maxorder}
	if (length(int.ord)>0){
		ord=int.ord[1]-1}
	return(ord)}
