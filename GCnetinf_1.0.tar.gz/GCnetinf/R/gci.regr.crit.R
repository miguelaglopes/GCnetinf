gci.regr.crit <-
function(model,method){
	rss=sum(model[[2]]^2)
	n=length(model[[2]])
	k=model[[4]] ## k is the rank of the model - number of independent variables + intercept
	if (method=="aic"){
		out=n*log(rss/n)+2*k}
	if (method=="aicc"){
		out=n*log(rss/n)+2*k
		out=out+(2*k)*(k+1)/(n-k-1)
		## in case it returns infinity.test! return a very high value (meaning a bad model)
		if ( (n-k-1)==0){
			out=10000}}
	if (method=="bic"){ 
		out=n*log(rss/n)+k*log(n)
		if (rss==0){
			out=10000}}
	return(out)}
