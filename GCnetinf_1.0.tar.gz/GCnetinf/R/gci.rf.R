gci.rf <-
function(exprdata, rf.importance, rf.mtry, rf.ntrees){
	print("RANDOM FORESTS")
	out=mat.or.vec(nrow(exprdata),nrow(exprdata))
	checkseq=1:100
	for (y in 1:nrow(exprdata)){
		if (any(checkseq==round(y/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(y/nrow(exprdata),2)*100)]
			cat(paste(round(y/nrow(exprdata),2)*100, "% ", sep=""))}
		target=exprdata[y,-1]
		predictors=exprdata[,-ncol(exprdata)]
		rownames(predictors)=1:nrow(predictors)	
		out[,y]=gci.rf.target(target, predictors, rf.importance, rf.mtry, rf.ntrees)}
	return(out)}
