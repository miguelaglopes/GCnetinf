gci.rf.target <-
function(target, predictors, rf.pars){
	if (is.null(dim(predictors))){
		predictors=as.matrix(t(predictors))}
    rf.pars=c(list(x=t(predictors), y=target), rf.pars)
    rf <- do.call(randomForest::randomForest, rf.pars)
	im <- randomForest::importance(rf)[,"IncNodePurity"]	
	return(im)}





