gci.rf.target <-
function(target, predictors, rf.importance, rf.mtry, rf.ntrees){
	if (is.null(dim(predictors))){
		predictors=as.matrix(t(predictors))}
    rf <- randomForest::randomForest(t(predictors), target, mtry=rf.mtry, ntree=rf.ntrees, importance=TRUE)
	im <- importance::importance(rf)[,rf.importance]	
	return(im)}
