gci.sibling.fun <-
function(exprdata,mincor,maxlag){ 
	out=mat.or.vec(nrow(exprdata),nrow(exprdata))
	corMAT=abs(cor(t(exprdata)))
	pv=gci.corrPV(corMAT,ncol(exprdata))
	pvL=mat.or.vec(nrow(exprdata),nrow(exprdata))+1
	for (i in 1:maxlag){
		exprdata1=exprdata[,-(1:i)]
		exprdata2=exprdata[,-(ncol(exprdata)-(1:i)+1)]
		exprdata1=t(apply(exprdata1, 1, function(x) (x-mean(x))/sd(x)))
		exprdata2=t(apply(exprdata2, 1, function(x) (x-mean(x))/sd(x)))	
		corMATL=(exprdata1%*%t(exprdata2))/(ncol(exprdata1)-1)
		corMATL=abs(corMATL)
		indSUB=which(corMATL-t(corMATL)<0)
		corMATL[indSUB]=t(corMATL)[indSUB]
		pvL2=gci.corrPV(corMATL,ncol(exprdata1))
		indSUB=which(pvL2<pvL)
		pvL[indSUB]=pvL2[indSUB]
		}
	indCO=which(pv<pvL)
	indCO=intersect(indCO, which(corMAT>mincor))
	out[indCO]=1
	return(out)}
