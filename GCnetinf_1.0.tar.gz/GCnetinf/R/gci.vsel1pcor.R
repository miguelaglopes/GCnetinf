gci.vsel1pcor <-
function(exprdata,method,cutoff){
	n.genes=nrow(exprdata)
	out=mat.or.vec(n.genes, n.genes)
	checkseq=1:100
	for (i in 1:n.genes){
		if (any(checkseq==round(i/nrow(exprdata),2)*100)){
			checkseq=checkseq[-which(checkseq==round(i/nrow(exprdata),2)*100)]
			cat(paste(round(i/nrow(exprdata),2)*100, "% ", sep=""))}
		target=exprdata[i,-1]
		preds=exprdata[,-ncol(exprdata)]
		rownames(preds)=1:nrow(preds)
		mi.mat=gci.cor2mi(cor(t(rbind(preds,target))))
		corrP=gci.corrPV(gci.mi2cor(mi.mat[-ncol(mi.mat),ncol(mi.mat)]),length(target))		
		indpreds=which(corrP<cutoff)
		if (length(indpreds)>0){
			mi.mat=mi.mat[c(indpreds,ncol(mi.mat)),c(indpreds,ncol(mi.mat))]
			preds=preds[indpreds,]			
			if (length(indpreds)==1){
				preds=t(preds)}
			if (method=="cmim"){
				target.prediction=gci.cmi.sel(preds,target,mi.mat,type="min")
				out[indpreds,i]=target.prediction}				
			if (method=="mimr"){
				target.prediction=gci.cmi.sel(preds,target,mi.mat,type="mean")
				out[indpreds,i]=target.prediction}}}
	return(out)}
