netinf1l <-
function(datamatrix,
					Methods,
					mi.cutoff=0.05,
					rf.importance="IncNodePurity",
					rf.mtry=round(sqrt(ncol(exprdata))),
					rf.ntrees=1000,
					lars.type="lasso",
					lars.use.gram=TRUE,
					lars.mode="fraction",
					lars.path=seq(0.1,1,0.01)){
	if (any(!all(is.numeric(datamatrix)))){stop("Non numeric values found")}
	if (any(is.na(datamatrix))){stop("NA values found")}
	if (any(abs(datamatrix)==Inf)){stop("Inf values found")}
	exprdata=t(datamatrix)
	predictions=list()
	if (any(c("mi","aracne","clr")%in%Methods)){
		mi.mat=gci.cor2mi(gci.cor.mat(exprdata))}
	for (m in 1:length(Methods)){
		method=Methods[m]
		if (method=="mi"){
			predictions[[m]]=mi.mat}
		if (method=="aracne"){
			predictions[[m]]=gci.aracne(mi.mat)}
		if (method=="clr"){
			predictions[[m]]=gci.clr(mi.mat)}
		if (method=="mrmr"){
			predictions[[m]]=gci.mrmr(exprdata)}
		if (method=="cmim"){
			predictions[[m]]=gci.cmim(exprdata,mi.cutoff)}		
		if (method=="mimr"){
			predictions[[m]]=gci.mimr(exprdata,mi.cutoff)}				
		if (method=="rf"){
			predictions[[m]]=gci.rf(exprdata,rf.importance,rf.mtry,rf.ntrees)}
		if (method=="lars"){
			predictions[[m]]=gci.lars(exprdata,lars.type,lars.use.gram,lars.mode,lars.path)}}
	names(predictions)=Methods
	REM=which(unlist(lapply(predictions, is.null)))
	if (length(REM)>0){
		predictions=predictions[-REM]}
	for (m in 1:length(predictions)){
		diag(predictions[[m]])=min(predictions[[m]])
		predictions[[m]]=predictions[[m]]-min(predictions[[m]])}
	return(predictions)}
